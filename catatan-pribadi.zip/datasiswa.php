<?php
	include('pages/head.php');
?>
<body>
	<div class="wrapper">
		<?php include("pages/header.php"); ?>
		<!-- Sidebar -->
		<?php include("pages/sidebar.php"); ?>
		<div class="main-panel">
			<div class="content">
				<div class="page-inner">
					<div class="page-header">
						<h4 class="page-title">Data Siswa</h4>
						<ul class="breadcrumbs">
							<li class="nav-home">
								<a href="#">
									<i class="flaticon-home"></i>
								</a>
							</li>
							<li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li>
							<li class="nav-item">
								<a href="#">Data Sekolah</a>
							</li>
							<!-- <li class="separator">
								<i class="flaticon-right-arrow"></i>
							</li> -->
							<!-- <li class="nav-item">
								<a href="#">Kelas 7</a>
							</li> -->
						</ul>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="card">
                                <!-- <div class="card-header">
									<h4 class="card-title">List Data</h4>
								</div> -->
								
								<div class="card-body">
									<div class="row">
										<div class="col-4 col-md-3">
											<div class="nav flex-column nav-pills nav-secondary" id="v-pills-tab" role="tablist" aria-orientation="vertical">
												<a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#v-pills-1" role="tab" aria-controls="v-pills-1" aria-selected="true">Data Pribadi</a>
												<a class="nav-link" id="v-pills-2-tab" data-toggle="pill" href="#v-pills-2" role="tab" aria-controls="v-pills-2" aria-selected="false">Orang Tua</a>
                                                <a class="nav-link" id="v-pills-3-tab" data-toggle="pill" href="#v-pills-3" role="tab" aria-controls="v-pills-3" aria-selected="false">Data Wali</a>
												<a class="nav-link" id="v-pills-4-tab" data-toggle="pill" href="#v-pills-4" role="tab" aria-controls="v-pills-4" aria-selected="false">Hasil Non Tes</a>
												<a class="nav-link" id="v-pills-5-tab" data-toggle="pill" href="#v-pills-5" role="tab" aria-controls="v-pills-5" aria-selected="false">Kesehatan & Ekonomi</a>
												<a class="nav-link" id="v-pills-6-tab" data-toggle="pill" href="#v-pills-6" role="tab" aria-controls="v-pills-6" aria-selected="false">Hubungan engan Teman</a>
												<a class="nav-link" id="v-pills-7-tab" data-toggle="pill" href="#v-pills-7" role="tab" aria-controls="v-pills-7" aria-selected="false">Sikap & Tata Krama</a>
												<a class="nav-link" id="v-pills-8-tab" data-toggle="pill" href="#v-pills-8" role="tab" aria-controls="v-pills-8" aria-selected="false">Data Belajar</a>
												<a class="nav-link" id="v-pills-9-tab" data-toggle="pill" href="#v-pills-9" role="tab" aria-controls="v-pills-9" aria-selected="false">Nilai Raport</a>
												<a class="nav-link" id="v-pills-10-tab" data-toggle="pill" href="#v-pills-10" role="tab" aria-controls="v-pills-10" aria-selected="false">DPD</a>
												<a class="nav-link" id="v-pills-11-tab" data-toggle="pill" href="#v-pills-11" role="tab" aria-controls="v-pills-11" aria-selected="false">Rekomendasi Peminatan</a>
												<a class="nav-link" id="v-pills-12-tab" data-toggle="pill" href="#v-pills-12" role="tab" aria-controls="v-pills-12" aria-selected="false">Riwayat Mutasi</a>
                                                
											</div>
										</div>
										<div class="col-8 col-md-9">
											<div class="tab-content" id="v-pills-tabContent">
												<div class="tab-pane fade show active" id="v-pills-1" role="tabpanel" aria-labelledby="v-pills-2-tab">
													<div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">Nomor</label>
                                                                <input type="number" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">Bahasa Sehari-hari</label>
                                                                <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">NISN</label>
                                                                <input type="number" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">Kewarganegaraan</label>
                                                                <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">NISN</label>
                                                                <input type="number" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">Alamat</label>
                                                                <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">Nama Lengkap</label>
                                                                <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallSelect">Tinggal dengan</label>
                                                                <select class="form-control form-control-sm" id="smallSelect">
                                                                    <option>Ayah Kandung</option>
                                                                    <option>Ibu Kandung</option>
                                                                    <option>Ayah Tiri</option>
                                                                    <option>Ibu Tiri</option>
                                                                    <option>Wali</option>
                                                                    <option>Numpang keluarga lain</option>
                                                                    <option>Kos</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallInput">Alasan</label>
                                                                <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label for="smallSelect">Lingkungan dekat dengan</label>
                                                                <select class="form-control form-control-sm" id="smallSelect">
                                                                    <option>Madrasah</option>
                                                                    <option>Asrama Militer</option>
                                                                    <option>Komplek perumahan biasa</option>
                                                                    <option>Rumah MAsyarakat</option>
                                                                    <option>PAsar/Pertokoan</option>
                                                                    <option>Tempat Hiburan</option>
                                                                    <option>Pabrik</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <b>Riwayat Kelas :</b>
                                                                <div class="row">
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="smallInput">Kelas 7</label>
                                                                            <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="smallInput">Kelas 8</label>
                                                                            <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">
                                                                        <div class="form-group">
                                                                            <label for="smallInput">Kelas 9</label>
                                                                            <input type="text" class="form-control form-control-sm" id="smallInput" placeholder="Small Input">
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
												</div>
												<div class="tab-pane fade" id="v-pills-2" role="tabpanel" aria-labelledby="v-pills-2-tab">
													<p>Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
													<p>The Big Oxmox advised her not to do so, because there were thousands of bad Commas, wild Question Marks and devious Semikoli, but the Little Blind Text didn’t listen. She packed her seven versalia, put her initial into the belt and made herself on the way.
													</p>
												</div>
												<div class="tab-pane fade" id="v-pills-3" role="tabpanel" aria-labelledby="v-pills-3-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-4" role="tabpanel" aria-labelledby="v-pills-4-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-5" role="tabpanel" aria-labelledby="v-pills-5-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-6" role="tabpanel" aria-labelledby="v-pills-6-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-7" role="tabpanel" aria-labelledby="v-pills-7-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-8" role="tabpanel" aria-labelledby="v-pills-8-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-9" role="tabpanel" aria-labelledby="v-pills-9-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-10" role="tabpanel" aria-labelledby="v-pills-10-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-11" role="tabpanel" aria-labelledby="v-pills-11-tab">
													
                                                </div>
                                                <div class="tab-pane fade" id="v-pills-12" role="tabpanel" aria-labelledby="v-pills-12-tab">
													
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php include("pages/footer.php"); ?>
		</div>
	</div>
	<!--   Core JS Files   -->
	<?php include("pages/foot.php"); ?>
</body>
</html>